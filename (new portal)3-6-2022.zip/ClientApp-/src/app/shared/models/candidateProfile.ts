export interface ICandidateProfile{

    FirstName:string,
    MiddleName:string,
    LastName:string,
    Country:string,

    EducationLevel:string,
    ProfileImgPath:string,
    City:string,
    CvPath:string,


       // Street:string,
    // ZipCode:string,

}