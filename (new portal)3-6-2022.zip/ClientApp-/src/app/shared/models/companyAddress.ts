
export class CompanyAddess {

    Id:number;
    IndustryName:string;
    CompanyProfileId:number;
}
  



