export class MultiSelectIndustries{
    industryName:string;
    companyProfileId:number;
}