export interface IUser {
  id: string,
  email: string,
  displayName: string,
  //   UserName :string,
  role: string,
  token: string,

}