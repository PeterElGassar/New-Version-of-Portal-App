export interface ICompanyIndustry{


    Id:number;
    IndustryName:string
    CompanyProfileId:number;

    // public int Id { get; set; }
    // public int IndustryName { get; set; }
    // public int CompanyProfileId { get; set; }
}