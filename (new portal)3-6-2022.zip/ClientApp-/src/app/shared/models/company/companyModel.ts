import { CompanyAddess } from "../companyAddress";

export class Company {

    id:number;
    companyName:string;
    imgLogoPath:string;
    foundedDate:Date;
    createAt:Date;
    companySize:string;
    linkedIn:string;
    feacbook:string;
    website:string;
    appUserId:string;

    companyDescription:string;

    companyIndustries:CompanyAddess[];

}
  



