export interface     ICompanyPhoneNumber{

    id:number;
    phoneNumber:number;
    companyProfileId:number;
    // public int Id { get; set; }
    // public int PhoneNumber { get; set; }
    // public int CompanyProfileId { get; set; }
}    