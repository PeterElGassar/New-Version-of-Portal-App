export interface IIndustry{
    id:number;
    industryName:string;
}