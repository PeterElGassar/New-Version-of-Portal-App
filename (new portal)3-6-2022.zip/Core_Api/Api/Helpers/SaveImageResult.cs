﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Helpers
{
    public class SaveImageResult
    {
        public string Path { get; set; }
        public bool Status { get; set; }
    }
}
