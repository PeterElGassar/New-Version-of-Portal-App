﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.SD
{
    public class SD
    {
        public enum userRoles
        {
            Admin=1,
            Company=2,
            Candidate=3
        }
    }
}
