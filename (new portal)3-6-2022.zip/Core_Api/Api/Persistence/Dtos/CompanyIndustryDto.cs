﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Persistence.Dtos
{
    public class CompanyIndustryDto
    {
        //public int Id { get; set; }
        public string IndustryName { get; set; }

        public int CompanyProfileId { get; set; }
    }
}
